# Kickstarting with Excel; Deliverable 3

## Overview of Project

Louise almost achieved her fundraising goal for Fever", her theatrical play. She is curious and has asked me to investigate the outcomes of other crowdfunding campaigns and to find--if any--conclusions in relevance to the launch dates and fundraising goals. 

### Purpose

Using Microsoft Excel, I will visualize campaign outcomes based on their launch dates and funding goals. More specifically for this assignment, I will utilize PivotTables, PivotCharts, CountIfs, and basic formulas in order to visualize aspects of interest in the data set and draw conclusions regarding the launch dates, fundraising goals, and outcomes.

## Analysis and Challenges

 I faced some difficulties while completing this assignment. The first was that when I was setting up my PivotTable for the Theater Outcomes by Launch Date sheet, I accidentally exited out of the PivotTable Field and I was unable to access it again. I fixed this issue after searching up how to access a PivotTable after closing out the sidebar, and the results suggested to click on a cell in the PivotTable, click PivotTable Analyze and then hit Field List under the Show subcategory. The second issue was that I did not realize the assigmennt asked to focus only on plays for deliverable two, so my countifs were originally innaccurate. I fixed this by adding Kickstarter!R2:R4115, "=plays", to the code. The last challenge that I faced was that I was not sure of the proper Microsoft Excel nomenclature for both greater than and equal to and less than and equal to, and this was impacting the number of counts for the different outcomes categories as well as my PivotChart. After I searched up online how I should type this, I was able to produce the correct chart.

### Analysis of Outcomes Based on Launch Date

Throughout 2009 to 2017, 111 successful theaters were launched in May. 100 successful theaters launched in June. According to this, the beginning of Summer is a great time to launch a play if your team desire to sucessfully meet their fundraising goal. To add on, this is solidified by viewing the data for the most recent full year, 2016. The smallest number of successful campaigns occurred during December, capping at 8, concluding that campaigns are more likely to fail if launched in Decemember, this may be due to widely celebrated winter holidays taking place during the same time, and most people will choose to spend their money on friends and family instead of a stranger's play.

### Analysis of Outcomes Based on Goals

The greatest percentage successful occurred when the fundraising goal was less than 1000 USD. The second greatest percentage successful occurred when the fundraising goal was between 1000 and 4999 USD. Thus, a conclusion that can be made is that to have a better chance of fully achieving her goal, Louise should keep her fundraising target under 4999 USD. 

### Limitations on the Data Set

One limitation of the this dataset is that data from October is missing for plays that were canceled. Additionally, it appears as though most of the plays investigated are from the US and Great Britain, AKA GB. There could potentially be an underlying reason for this; for example, the dataset is collected only by English speakers and they are only investigating outcomes for plays performed in English. Having a bias towards one language could impact our findings. 

## Results

Some other tables and graphs that we could create are displayed in the Other Possible Tables & Graphs Sheet. I put Years and Subcategory in Filters, Outcomes in Columns, Country in Rows, and Count of Outcomes in Values. Using a bar chart to visualize this data, you can see that the US and GB have the greatest total number of crowdfunding campaigns. Since these two are clearly outliers, another graph that could be made is the same as stated previously, but filtering out US and GB, in order to better view the other countries. This can help us propose other questions such as why do  other countries not have as many total crowdfunding campaigns for entertainment and/or the arts? As well as could a lesser number of total crowdfunding campaigns signify that fundraising is not necessary to launch a successful project abroad?