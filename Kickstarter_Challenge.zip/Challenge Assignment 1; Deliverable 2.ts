
// deliverable two

// getting the correct counts in each category - first one is number successful 

=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, "<=1000", Kickstarter!F2:F4115, "=successful")
=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, ">=1000", Kickstarter!D2:D4115, "<=4999", Kickstarter!F2:F4115, "=successful")
=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, ">=5000", Kickstarter!D2:D4115, "<=9999", Kickstarter!F2:F4115, "=successful")
=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, ">=10000", Kickstarter!D2:D4115, "<=14999", Kickstarter!F2:F4115, "=successful")
=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, ">=15000", Kickstarter!D2:D4115, "<=19999", Kickstarter!F2:F4115, "=successful")
=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, ">=20000", Kickstarter!D2:D4115, "<=24999", Kickstarter!F2:F4115, "=successful")
=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, ">=25000", Kickstarter!D2:D4115, "<=29999", Kickstarter!F2:F4115, "=successful")
=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, ">=30000", Kickstarter!D2:D4115, "<=34999", Kickstarter!F2:F4115, "=successful")
=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, ">=35000", Kickstarter!D2:D4115, "<=39999", Kickstarter!F2:F4115, "=successful")
=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, ">=40000", Kickstarter!D2:D4115, "<=44999", Kickstarter!F2:F4115, "=successful")
=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, ">=45000", Kickstarter!D2:D4115, "<=49999", Kickstarter!F2:F4115, "=successful")
=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, ">=50000", Kickstarter!F2:F4115, "=successful")

// second category is number failed 

=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, "<=1000", Kickstarter!F2:F4115, "=failed")
=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, ">=1000", Kickstarter!D2:D4115, "<=4999", Kickstarter!F2:F4115, "=failed")
=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, ">=5000", Kickstarter!D2:D4115, "<=9999", Kickstarter!F2:F4115, "=failed")
=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, ">=10000", Kickstarter!D2:D4115, "<=14999", Kickstarter!F2:F4115, "=failed")
=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, ">=15000", Kickstarter!D2:D4115, "<=19999", Kickstarter!F2:F4115, "=failed")
=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, ">=20000", Kickstarter!D2:D4115, "<=24999", Kickstarter!F2:F4115, "=failed")
=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, ">=25000", Kickstarter!D2:D4115, "<=29999", Kickstarter!F2:F4115, "=failed")
=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, ">=30000", Kickstarter!D2:D4115, "<=34999", Kickstarter!F2:F4115, "=failed")
=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, ">=35000", Kickstarter!D2:D4115, "<=39999", Kickstarter!F2:F4115, "=failed")
=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, ">=40000", Kickstarter!D2:D4115, "<=44999", Kickstarter!F2:F4115, "=failed")
=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, ">=45000", Kickstarter!D2:D4115, "<=49999", Kickstarter!F2:F4115, "=failed")
=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, ">=50000", Kickstarter!F2:F4115, "=failed")

// third category is number canceled 

=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, "<=1000", Kickstarter!F2:F4115, "=canceled")
=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, ">=1000", Kickstarter!D2:D4115, "<=4999", Kickstarter!F2:F4115, "=canceled")
=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, ">=5000", Kickstarter!D2:D4115, "<=9999", Kickstarter!F2:F4115, "=canceled")
=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, ">=10000", Kickstarter!D2:D4115, "<=14999", Kickstarter!F2:F4115, "=canceled")
=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, ">=15000", Kickstarter!D2:D4115, "<=19999", Kickstarter!F2:F4115, "=canceled")
=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, ">=20000", Kickstarter!D2:D4115, "<=24999", Kickstarter!F2:F4115, "=canceled")
=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, ">=25000", Kickstarter!D2:D4115, "<=29999", Kickstarter!F2:F4115, "=canceled")
=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, ">=30000", Kickstarter!D2:D4115, "<=34999", Kickstarter!F2:F4115, "=canceled")
=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, ">=35000", Kickstarter!D2:D4115, "<=39999", Kickstarter!F2:F4115, "=canceled")
=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, ">=40000", Kickstarter!D2:D4115, "<=44999", Kickstarter!F2:F4115, "=canceled")
=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, ">=45000", Kickstarter!D2:D4115, "<=49999", Kickstarter!F2:F4115, "=canceled")
=COUNTIFS(Kickstarter!R2:R4115, "=plays", Kickstarter!D2:D4115, ">=50000", Kickstarter!F2:F4115, "=canceled")

// format f2:h13 as percentage then add the following to percentage successful

=b2/e2

// right click the bottom right corner of the cell to fill the rest of the B column, proceed same steps with following columns 

// moving on to percentage failed 

=c2/e2

// right click the bottom right corner of the cell to fill the rest of the C column 

// moving on to percentage canceled 

=d2/e2

// right click the bottom right corner of the cell to fill the rest of the D column 
